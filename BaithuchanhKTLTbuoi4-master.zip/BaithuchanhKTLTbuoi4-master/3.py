S = input("Nhap chuoi: ")
for ch in S:
    print(ch.upper())