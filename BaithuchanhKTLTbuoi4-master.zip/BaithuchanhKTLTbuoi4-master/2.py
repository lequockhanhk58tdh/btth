S = input("Nhap chuoi: ")
for ch in S:
    if ch.isspace():
        continue
    else:
         print(ch)
print(ch)