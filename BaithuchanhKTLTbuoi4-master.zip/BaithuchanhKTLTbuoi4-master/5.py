ds = input("Danh sach ---> ").split()
ds.reverse()
for so in ds:
    print(so)