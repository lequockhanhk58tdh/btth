S = input("Nhap chuoi: ").split()
S.sort()
print (S)
