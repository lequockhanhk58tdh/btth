ds = input("Danh sach ---> ").split()
print(ds)
for so in ds:
    print(so)