import math
r = float(input("Nhap vao ban kinh hinh tron ---> "))
chuvi = 2*math.pi*r
dientich = math.pi*r*r
print("Chu vi hinh tron co ban kinh {0} la ---> {1} ".format(r,chuvi))
print("Dien tich hinh tron co ban kinh {0} la ---> {1} ".format(r,dientich))