def kiemtraGiatri(n):
    if n % 2 == 0:
        print("Day la so chan")
    else:
        print("Day la so le")
n = int(input("Nhap so can kiem tra ---> "))
kiemtraGiatri(n)