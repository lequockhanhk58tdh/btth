def sum(a,b):
    print("sum = " +str(a+b))
# Tinh tong hai so 4 va 5
sum(4,5)
# Tinh tong hai so 3 va 7
sum(3,7)