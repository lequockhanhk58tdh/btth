a = "Hello Guy!"
def say(a):
    a = "Vinh University"
    print(a)
say(a)
print(a)