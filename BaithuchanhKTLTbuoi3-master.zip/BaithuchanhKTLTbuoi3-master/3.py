def say_hello():
    a = "Hello"
    print(a)