import shutil
shutil.copy('D:/a.txt', 'D:/b.txt')