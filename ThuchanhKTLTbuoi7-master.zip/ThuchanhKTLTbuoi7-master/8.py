with open("D:/a.txt", 'a+') as f:
    f.write("\nLê Hoài Nam")
