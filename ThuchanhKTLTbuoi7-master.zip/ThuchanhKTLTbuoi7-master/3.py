S = open('D:/a.txt', 'r')
print(S.read())