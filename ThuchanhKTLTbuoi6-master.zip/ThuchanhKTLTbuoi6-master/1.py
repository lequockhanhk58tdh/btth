class Circle(object):
    def __int__(self, r):
        self.radius = r
    def area(self):
        return self.radius**2*3.14

aCircle = Circle(2)
print(aCircle.area())