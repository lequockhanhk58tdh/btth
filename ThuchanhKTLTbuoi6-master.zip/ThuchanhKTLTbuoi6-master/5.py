class py_solution():
    def reverse_words(self, s):
        return ''.join(reversed(s))

print(py_solution().reverse_words('Hello.py'))
