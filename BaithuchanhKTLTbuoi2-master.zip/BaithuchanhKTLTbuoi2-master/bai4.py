i = 1;
for j in range (1,5):
    print("i:",i,"j:",j)
    print(i,"/",j)
    print(i/j)