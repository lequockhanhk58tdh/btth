a = "Hi I am python programer"
b = a.split()
print(b)
c = " ".join(b)
print(c)