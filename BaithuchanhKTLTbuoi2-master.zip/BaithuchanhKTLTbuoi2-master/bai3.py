n = int(input("Nhap so can kiem tra ---> "))
if n % 2 == 0:
    print("So vua nhap la so chan")
else:
    print("So vua nhap la so le")
