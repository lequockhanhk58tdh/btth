# BaithuchanhKTLTbuoi2
Thực hành KTLT buổi 2
