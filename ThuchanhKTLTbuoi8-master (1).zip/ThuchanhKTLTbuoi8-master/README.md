# ThuchanhKTLTbuoi8
Bài thực hành KTLT 8
