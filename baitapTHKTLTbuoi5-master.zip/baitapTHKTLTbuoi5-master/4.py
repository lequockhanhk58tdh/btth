import numpy as np
x = np.arange(12, 38)
print("Mảng gốc: ", x)
print("Mảng đảo ngược: ", x[::-1])
