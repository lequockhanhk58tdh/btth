def minmax(S):
   min(S)
   max(S)
   print("Phần tử lớn nhất: ", max(S))
   print("Phần tử nhỏ nhất: ", min(S))

S = input("List cần kiểm tra: ").split()
minmax(S)