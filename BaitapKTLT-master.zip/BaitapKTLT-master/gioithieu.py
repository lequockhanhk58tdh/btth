Python 3.7.2 (tags/v3.7.2:9a3ffc0492, Dec 23 2018, 22:20:52) [MSC v.1916 32 bit (Intel)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> print('Hello World')
Hello World
>>> print('Ho ten: Le Hoai Nam')
Ho ten: Le Hoai Nam
>>> print('MSSV: 1755252021600007')
MSSV: 1755252021600007
>>> print('Lop: 58k - Ky thuat Dieu khien & Tu dong hoa')
Lop: 58k - Ky thuat Dieu khien & Tu dong hoa
>>> 
