n = int(input("Nhap so nguyen n: "))
def printDict():
    d=dict()
    for i in range(1,n + 1):
       d[i]=i**2
    print (d)
printDict()