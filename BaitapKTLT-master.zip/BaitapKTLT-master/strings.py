my_string = input("Nhap chuoi bat ky ---> ")
print("Do dai chuoi vua nhap la ---> ",len(my_string))
print("Chuoi viet hoa hoan toan ---> ",my_string.upper())
