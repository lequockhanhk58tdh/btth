S = input("Nhap chuoi: ")
print(S.upper())