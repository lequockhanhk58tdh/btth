x, y = 0, 1
while y < 1000:
    print(y)
    x, y = y, x + y
