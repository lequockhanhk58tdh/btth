S = input("Nhap chuoi so: ").split(",")
t = tuple(S)
print (t)